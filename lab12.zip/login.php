<?php
session_start();

require_once './connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {    
    $username = $mysql->real_escape_string($_POST["username"]);
    $password =  $mysql->real_escape_string($_POST["password"]);

    $sql = "SELECT * FROM customer WHERE username = '".$username."' AND password = '".$password."'";
    $result = mysqli_query($mysql, $sql);
    if (mysqli_num_rows($result) > 0) {
        $row = $result->fetch_assoc();

        $_SESSION["username"] = $row["username"];
        $_SESSION["firstname"] = $row["Customer_Name"];
        $_SESSION["surname"] = $row["Customer_Lastname"];

        header("Location: show_customer.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f0f0f0;
        }

        .login-box {
            border: 2px solid black;
            padding: 50px;
            background-color: white;
            box-shadow: 0px 0px 10px 0px #000;
        }

        .login-box h2 {
            text-align: left;
            font-size: 18px;
        }

        .login-box label {
            display: block;
            margin-bottom: 8px;
        }

        .login-box input[type="text"],
        .login-box input[type="password"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .login-box input[type="submit"],
        .login-box input[type="button"] {
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .login-box input[type="submit"] {
            background-color: #4CAF50;
            color: white;
        }

        .login-box input[type="button"] {
            background-color: #f44336;
            color: white;
        }
    </style>
</head>

<body>
    <div class="login-box">
        <h2>Log In</h2>
        <form action="login.php" method="post">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>

            <input type="submit" value="Login">
            <input type="button" value="Cancel" onclick="window.location.href='index.php';">
        </form>
    </div>
</body>

</html>