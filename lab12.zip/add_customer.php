<?php
require_once 'connection.php';

$month = array(
    "มกราคม",
    "กุมภาพันธ์",
    "มีนาคม",
    "เมษายน",
    "พฤษภาคม",
    "มิถุนายน",
    "กรกฎาคม",
    "สิงหาคม",
    "กันยายน",
    "ตุลาคม",
    "พฤศจิกายน",
    "ธันวาคม"
);


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Connect MySQL server
    $mysql = mysqli_connect("localhost", "root", "", "mystore");
    if (mysqli_connect_errno()) {
        exit("" . mysqli_connect_error());
    }

    // Customer
    $firstname = $mysql->real_escape_string($_POST["firstname"]);
    $lastname = $mysql->real_escape_string($_POST["lastname"]);
    $gender = $mysql->real_escape_string($_POST["gender"]);
    $birth_day = $mysql->real_escape_string($_POST["birth_day"]);
    $birth_month = $mysql->real_escape_string($_POST["birth_month"]);
    $birth_year = $mysql->real_escape_string($_POST["birth_year"]);
    $address = $mysql->real_escape_string($_POST["address"]);
    $province = $mysql->real_escape_string($_POST["province"]);
    $postcode = $mysql->real_escape_string($_POST["postcode"]);
    $phone = $mysql->real_escape_string($_POST["phone"]);
    $details = $mysql->real_escape_string($_POST["details"]);
    // Account
    $username = $mysql->real_escape_string($_POST["username"]);
    $password = $mysql->real_escape_string($_POST["password"]);
    $confirm_password = $mysql->real_escape_string($_POST["confirm_password"]);

    if ($password != $confirm_password) {
        exit("<h1>รหัสผ่านไม่ตรงกัน</h1>");
    }

    $sql = "INSERT INTO customer (Customer_Name, Customer_Lastname, Age, Gender, Birthdate, Address, Province, Zipcode, Telephone, Customer_Description, username, password)";
    $sql .= "VALUES('" . $firstname . "', '" . $lastname . "', 0, '" . $gender . "', '" . $birth_year . "-" . $birth_month . "-" . $birth_day . "', '" . $address . "', '" . $province . "', '" . $postcode . "', '" . $phone . "', '" . $details . "', '" . $username . "', '" . $password . "');";

    // Insert data
    $mysql->query($sql);

    header("Location: show_customer.php");
}
?>

<!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>เพิ่มข้อมูลลูกค้า</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
        }

        .form-container {
            width: 40%;
            /* ขนาดฟอร์ม */
            margin: 50px auto;
            border: 1px solid #ccc;
            padding: 15px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            color: red;
            text-align: center;
        }

        label {
            display: block;
            margin-top: 10px;
            font-size: 14px;
            /* ขนาดฟอนต์ */
        }

        input[type="text"],
        input[type="password"],
        textarea,
        select {
            width: 95%;
            /* ขนาดอินพุต */
            padding: 6px;
            margin-top: 5px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 14px;
            /* ขนาดฟอนต์ */
        }

        input[type="radio"] {
            margin-top: 5px;
        }

        input[type="submit"],
        input[type="reset"] {
            padding: 8px 16px;
            margin-top: 10px;
            cursor: pointer;
            font-size: 14px;
            /* ขนาดปุ่ม */
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            border: none;
        }

        input[type="reset"] {
            background-color: #f44336;
            color: white;
            border: none;
        }

        a[id="back"] {
            background-color: #f44336;
            color: white;
            border: none;
            padding: 8px 16px;
            margin-top: 10px;
            cursor: pointer;
            font-size: 14px;
            text-decoration: none;
        }

        .form-section {
            margin-bottom: 20px;
        }

        .account-section {
            margin-top: 20px;
            border-top: 1px solid #ccc;
            padding-top: 15px;
        }
    </style>
</head>

<body>

    <div class="form-container">
        <h2>เพิ่มข้อมูลลูกค้า</h2>
        <form name="customerForm" method="post" onsubmit="return validateForm()">
            <div class="form-section">
                <label>ชื่อ: </label><input type="text" name="firstname" onblur="validateInput(this, 3)">
                <label>นามสกุล: </label><input type="text" name="lastname" onblur="validateInput(this, 3)">
                <label>เพศ: </label>
                <input type="radio" name="gender" value="male"> ชาย
                <input type="radio" name="gender" value="girl"> หญิง

                <label>วันเกิด: </label>
                <select name="birth_day">
                    <option value="">วัน</option>
                    <?php for ($d = 1; $d <= 31; $d++): ?>
                        <option value="<?= str_pad($d, 2, '0', STR_PAD_LEFT); ?>"><?= $d; ?></option>
                    <?php endfor; ?>
                </select>
                <select name="birth_month">
                    <option value="">เดือน</option>
                    <?php for ($m = 0; $m < 12; $m++): ?>
                        <option value="<?= str_pad($m + 1, 2, '0', STR_PAD_LEFT); ?>"><?= $month[$m]; ?></option>
                    <?php endfor; ?>
                </select>
                <select name="birth_year">
                    <option value="">ปี</option>
                    <?php for ($y = 1900; $y <= date("Y"); $y++): ?>
                        <option value="<?= $y; ?>"><?= $y; ?></option>
                    <?php endfor; ?>
                </select>

                <label>ที่อยู่: </label><input type="text" name="address" onblur="validateInput(this,3)">
                <label>จังหวัด: </label><select name="province">
                    <option value="เชียงราย">เชียงราย</option>
                    <option value="เชียงใหม่">เชียงใหม่</option>
                    <option value="ลำปาง">ลำปาง</option>
                    <option value="ลำพูน">ลำพูน</option>
                    <option value="แพร่">แพร่</option>
                    <option value="น่าน">น่าน</option>
                    <option value="อุตรดิตถ์">อุตรดิตถ์</option>
                    <option value="สุโขทัย">สุโขทัย</option>
                    <option value="ตาก">ตาก</option>
                    <option value="พะเยา">พะเยา</option>
                    <!-- เพิ่มจังหวัดอื่น ๆ -->
                </select>
                <label>รหัสไปรษณีย์: </label><input type="text" name="postcode" onblur="validateInput(this, 5)" onkeyup="validateInputIsNumber(this)">
                <label>โทรศัพท์: </label><input type="text" name="phone" onblur="validateInput(this, 10)" onkeyup="validateInputIsNumber(this)">
                <label>รายละเอียดอื่นๆ: </label><textarea name="details"></textarea>
            </div>

            <div class="account-section">
                <h3>Account ของลูกค้า</h3>
                <label>Username: </label><input type="text" name="username" onblur="validateInput(this, 5)">
                <label>Password: </label><input type="password" name="password" onblur="validateInput(this, 8)">
                <label>Confirm Password: </label><input type="password" name="confirm_password">
            </div>

            <input type="submit" value="เพิ่มข้อมูลลูกค้า">
            <a id="back" href="show_customer.php">ยกเลิก</a>
        </form>
    </div>

    <script>
        function validateInput(i, size){
            if(!i.value) return;
            if(i.value.length < size){
                alert("กรุณากรอกข้อมูลให้ครบ")
            }
        }

        function validateInputIsNumber(i){
            const value = i.value
            const el = document.querySelector(`input[name=${i.name}]`)
            if(!value) return;
            if(!/^\d+$/.test(value)) {
                el.value = el.value.substring(0, el.value.length-1)
                return alert("กรุณากรอกตัวเลข")
            }
        }

        function validateForm() {
            // Get form fields
            var firstname = document.forms["customerForm"]["firstname"].value;
            var lastname = document.forms["customerForm"]["lastname"].value;
            var gender = document.forms["customerForm"]["gender"].value;
            var birthDay = document.forms["customerForm"]["birth_day"].value;
            var birthMonth = document.forms["customerForm"]["birth_month"].value;
            var birthYear = document.forms["customerForm"]["birth_year"].value;
            var address = document.forms["customerForm"]["address"].value;
            var postcode = document.forms["customerForm"]["postcode"].value;
            var phone = document.forms["customerForm"]["phone"].value;
            var username = document.forms["customerForm"]["username"].value;
            var password = document.forms["customerForm"]["password"].value;
            var confirmPassword = document.forms["customerForm"]["confirm_password"].value;

            // Validate required fields
            if (firstname == "" || lastname == "" || gender == "" || birthDay == "" || birthMonth == "" || birthYear == "" ||
                address == "" || postcode == "" || phone == "" || username == "" || password == "" || confirmPassword == "") {
                alert("กรุณากรอกข้อมูลให้ครบทุกช่อง");
                return false; // Prevent form submission
            }

            // Validate password confirmation
            if (password !== confirmPassword) {
                alert("รหัสผ่านและการยืนยันรหัสผ่านไม่ตรงกัน");
                return false;
            }

            // Validate phone number (optional)
            if (!/^\d{10}$/.test(phone)) {
                alert("กรุณากรอกเบอร์โทรศัพท์ให้ถูกต้อง (10 หลัก)");
                return false;
            }

            return true; // Form is valid, submit it
        }
    </script>
</body>

</html>