<?php
require_once "check_login.php";
require_once 'connection.php';

$sql = "SELECT * FROM customer c order by c.Customer_id desc;";
$result = mysqli_query($mysql, $sql);
?>

<!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="UTF-8">
    <title>ข้อมูลลูกค้า</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        h2 {
            color: blue;
        }

        a {
            color: red;
            text-decoration: none;
            font-weight: bold;
        }

        table {
            width: 70%;
            margin: 20px auto;
            border-collapse: collapse;
            border: 1px solid black;
        }

        th,
        td {
            border: 1px solid black;
            padding: 8px;
            text-align: center;
        }

        th {
            background-color: #f2f2f2;
        }

        .icon {
            width: 24px;
            height: 24px;
        }

        .add-button,
        .logout-button {
            margin-left: 70%;
            font-size: 18px;
            color: red;
            display: block;
        }

        .logout-button {
            margin-bottom: 10px;
            color: red;
            
        }

        .showname{
            margin-left: 10%;
            font-size: 18px;
            color: black;
            display: block;
        }
    </style>
</head>

<body>
    <h2 align="center">ข้อมูลลูกค้า</h2>

    <a class="showname" >ชื่อผู้ใช้ : <?= $_SESSION["firstname"]." ".$_SESSION["surname"] ?></a>

    <!-- ปุ่ม Log out -->
    <a class="logout-button" href="logout.php">Log out</a>

    <!-- ปุ่ม เพิ่มข้อมูลลูกค้า -->
    <a class="add-button" href="add_customer.php">
        <img class="icon" src="https://pub-588b96d72772408297efa6407775a3a9.r2.dev/plus.png" alt='plus' />เพิ่มข้อมูลลูกค้า
    </a>
    <table>
        <tr>
            <th>Id</th>
            <th>ชื่อ - สกุล</th>
            <th>จังหวัด</th>
            <th>โทรศัพท์</th>
            <th>แก้ไข</th>
            <th>ลบ</th>
        </tr>

        <?php
        if ($result->num_rows > 0) {
            // Output data of each row
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row["Customer_id"] . "</td>";
                echo "<td>" . $row["Customer_Name"] . " " . $row["Customer_Lastname"] . "</td>";
                echo "<td>" . $row["Province"] . "</td>";
                echo "<td>" . $row["Telephone"] . "</td>";
                echo "<td><a href='edit_customer.php?id=" . $row["Customer_id"] . "'><img class='icon' src='https://pub-588b96d72772408297efa6407775a3a9.r2.dev/edit.png' alt='Edit' /></a></td>";
                echo "<td><a href='delete_customer.php?id=" . $row["Customer_id"] . "'><img class='icon' src='https://pub-588b96d72772408297efa6407775a3a9.r2.dev/bin.png' alt='Delete' /></a></td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='6'>No data found</td></tr>";
        }
        ?>
    </table>

</body>

</html>