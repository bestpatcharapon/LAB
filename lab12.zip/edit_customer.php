<?php
require_once "check_login.php";
require_once 'connection.php';

$month = array(
    "มกราคม",
    "กุมภาพันธ์",
    "มีนาคม",
    "เมษายน",
    "พฤษภาคม",
    "มิถุนายน",
    "กรกฎาคม",
    "สิงหาคม",
    "กันยายน",
    "ตุลาคม",
    "พฤศจิกายน",
    "ธันวาคม"
);
$provinces = array(
    "เชียงราย",
    "เชียงใหม่",
    "ลำปาง",
    "แพร่",
    "น่าน",
    "อุตรดิตถ์",
    "ตาก",
    "พะเยา"
);


// Connect MySQL server
$mysql = mysqli_connect("localhost", "root", "", "mystore");
if (mysqli_connect_errno()) {
    exit("" . mysqli_connect_error());
}

$customerId = $mysql->real_escape_string($_GET["id"]);


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Customer
    $firstname = $mysql->real_escape_string($_POST["firstname"]);
    $lastname = $mysql->real_escape_string($_POST["lastname"]);
    $gender = $mysql->real_escape_string($_POST["gender"]);
    $birth_day = $mysql->real_escape_string($_POST["birth_day"]);
    $birth_month = $mysql->real_escape_string($_POST["birth_month"]);
    $birth_year = $mysql->real_escape_string($_POST["birth_year"]);
    $address = $mysql->real_escape_string($_POST["address"]);
    $province = $mysql->real_escape_string($_POST["province"]);
    $postcode = $mysql->real_escape_string($_POST["postcode"]);
    $phone = $mysql->real_escape_string($_POST["phone"]);
    $details = $mysql->real_escape_string($_POST["details"]);


    $sqlUpdate = "UPDATE customer SET ";
    $sqlUpdate .= "Customer_Name = '".$firstname."',";
    $sqlUpdate .= "Customer_Lastname = '".$lastname."',";
    $sqlUpdate .= "Gender = '".$gender."',";
    $sqlUpdate .= "Birthdate = '".$birth_year."-".$birth_month."-".$birth_day."',";
    $sqlUpdate .= "Address = '".$address."',";
    $sqlUpdate .= "Province = '".$province."',";
    $sqlUpdate .= "Zipcode = '".$postcode."',";
    $sqlUpdate .= "Telephone = '".$phone."',";
    $sqlUpdate .= "Customer_Description = '".$details."' ";
    $sqlUpdate .= "WHERE Customer_id = ".$customerId;
    

     // Insert data
     $mysql->query($sqlUpdate);

     header("Location: show_customer.php");
}

// Get user
$sql = "SELECT * FROM customer WHERE Customer_id = " . $customerId . " LIMIT 0,1";
$result = $mysql->query($sql);
if ($result->num_rows == 0) {
    exit("<h1>ไม่พบ Customer</h1>");
}

$customerInfo = $result->fetch_assoc();

list($birth_year, $birth_month, $birth_day) = explode("-", $customerInfo["Birthdate"]);
?>

<!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>แก้ไขข้อมูลลูกค้า</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
        }

        .form-container {
            width: 40%;
            /* ขนาดฟอร์ม */
            margin: 50px auto;
            border: 1px solid #ccc;
            padding: 15px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            color: red;
            text-align: center;
        }

        label {
            display: block;
            margin-top: 10px;
            font-size: 14px;
            /* ขนาดฟอนต์ */
        }

        input[type="text"],
        input[type="password"],
        textarea,
        select {
            width: 95%;
            /* ขนาดอินพุต */
            padding: 6px;
            margin-top: 5px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 14px;
            /* ขนาดฟอนต์ */
        }

        input[type="radio"] {
            margin-top: 5px;
        }

        input[type="submit"],
        input[type="reset"] {
            padding: 8px 16px;
            margin-top: 10px;
            cursor: pointer;
            font-size: 14px;
            /* ขนาดปุ่ม */
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            border: none;
        }

        input[type="reset"] {
            background-color: #f44336;
            color: white;
            border: none;
        }

        a[id="back"] {
            background-color: #f44336;
            color: white;
            border: none;
            padding: 8px 16px;
            margin-top: 10px;
            cursor: pointer;
            font-size: 14px;
            text-decoration: none;
        }

        .form-section {
            margin-bottom: 20px;
        }

        .account-section {
            margin-top: 20px;
            border-top: 1px solid #ccc;
            padding-top: 15px;
        }
    </style>
</head>

<body>

    <div class="form-container">
        <h2>แก้ไขข้อมูลลูกค้า</h2>
        <form method="post">
            <div class="form-section">
                <label>ชื่อ: </label><input type="text" value="<?= $customerInfo["Customer_Name"] ?>" name="firstname"
                    required>
                <label>นามสกุล: </label><input type="text" value="<?= $customerInfo["Customer_Lastname"] ?>"
                    name="lastname" required>
                <label>เพศ: </label>
                <input type="radio" name="gender" value="ชาย" required
                    checked="<?= $customerInfo["Gender"] == "male" ?>"> ชาย
                <input type="radio" name="gender" value="หญิง" required
                    checked="<?= $customerInfo["Gender"] == "girl" ?>"> หญิง

                <label>วันเกิด: </label>
                <select name="birth_day" required>
                    <option value="">วัน</option>
                    <?php
                    for ($d = 1; $d <= 31; $d++) {
                        $val = str_pad($d, 2, '0', STR_PAD_LEFT);
                        $attr = "value=\"" . $val . "\"";
                        if ($val == $birth_day) {
                            $attr .= " selected";
                        }
                        echo "<option " . $attr . ">" . $d . "</option>";
                    }
                    ?>
                </select>
                <select name="birth_month" required>
                    <option value="">เดือน</option>
                    <?php
                    for ($m = 1; $m <= 12; $m++) {
                        $val = str_pad($m, 2, '0', STR_PAD_LEFT);
                        $attr = "value=\"" . $val . "\"";
                        if ($val == $birth_month) {
                            $attr .= " selected";
                        }
                        echo "<option " . $attr . ">" . $month[$m - 1] . "</option>";
                    }
                    ?>
                </select>
                <select name="birth_year" required>
                    <option value="">ปี</option>
                    <?php
                    for ($y = 1900; $y <= date("Y"); $y++) {
                        $attr = "value=\"" . $y . "\"";
                        if ($y == $birth_year) {
                            $attr .= " selected";
                        }
                        echo "<option " . $attr . ">" . $y . "</option>";
                    }
                    ?>

                </select>

                <label>ที่อยู่: </label><input type="text" name="address" value="<?= $customerInfo["Address"] ?>"
                    required>
                <label>จังหวัด: </label>
                <select name="province">
                    <?php
                    for ($i = 0; $i < count($provinces); $i++) {
                        $name = $provinces[$i];
                        $attr = "value=\"" . $name . "\"";
                        if ($customerInfo["Province"] == $name) {
                            $attr .= " selected";
                        }
                        echo "<option " . $attr . ">" . $name . "</option>";
                    }
                    ?>
                </select>
                <label>รหัสไปรษณีย์: </label><input type="text" name="postcode" value="<?= $customerInfo["Zipcode"] ?>"
                    required>
                <label>โทรศัพท์: </label><input type="text" name="phone" value="<?= $customerInfo["Telephone"] ?>"
                    required>
                <label>รายละเอียดอื่นๆ: </label><textarea
                    name="details"><?= $customerInfo["Customer_Description"] ?></textarea>
            </div>

            <input type="submit" value="แก้ไขข้อมูลลูกค้า">
            <a id="back" href="show_customer.php">ยกเลิก</a>
        </form>
    </div>

</body>

</html>