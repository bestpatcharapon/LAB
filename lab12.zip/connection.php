<?php
// Connect MySQL server
$mysql = mysqli_connect("localhost", "root", "", "mystore");
if (mysqli_connect_errno()) {
    exit("" . mysqli_connect_error());
}