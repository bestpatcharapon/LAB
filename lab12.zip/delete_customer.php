<?php
require_once "check_login.php";
require_once 'connection.php';

$customerId = $mysql->real_escape_string($_GET["id"]);

$mysql->query("DELETE FROM customer WHERE Customer_id = ".$customerId);

header("Location: show_customer.php");
?>