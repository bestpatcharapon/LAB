<?php
require_once 'check_login.php';
session_destroy();
echo "<h1>ออกจากระบบแล้ว</h1> <a href=\"login.php\">ลงชื่อเข้าใจอีกครั้ง</a>";